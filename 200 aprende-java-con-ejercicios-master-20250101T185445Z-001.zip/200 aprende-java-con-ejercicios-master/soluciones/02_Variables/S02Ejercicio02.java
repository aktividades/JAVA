/**
 * 2. Variables
 *
 * 2. Crea la variable nombre y asígnale tu nombre completo. Muestra su
 *    valor por pantalla de tal forma que el resultado del programa sea
 *    el mismo que en el ejercicio 1 del capítulo 1.
 *
 * @author Luis José Sánchez
 */

public class S02Ejercicio02 {
  public static void main(String[] args) {
    String nombre = "Luis José Sánchez González";
    System.out.println(nombre);
  }
}
