/**
 *
 * 2. Variables
 *
 * 3. Crea las variables nombre, direccion y telefono y asígnale los
 *    valores correspondientes. Muestra los valores de esas variables
 *    por pantalla de tal forma que el resultado del programa sea el
 *    mismo que en el ejercicio 2 del capítulo 1.
 *
 * @author Luis José Sánchez
 */

public class S02Ejercicio03 {
  public static void main(String[] args) {
    String nombre = "Luis José Sánchez González";
    String direccion = "Larios, 180 - Málaga";
    String telefono = "Tel: 555 12 34 56";
    System.out.println(nombre);
    System.out.println(direccion);
    System.out.println(telefono);
  }
}
