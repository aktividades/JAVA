/**
 * 1. Salida por pantalla
 *
 * 1. Escribe una programa que muestre tu nombre por pantalla.
 *
 * @author Luis José Sánchez
 */

public class S01Ejercicio01 {
  public static void main(String[] args) {
    System.out.println("Luis José Sánchez González");
  }
}
