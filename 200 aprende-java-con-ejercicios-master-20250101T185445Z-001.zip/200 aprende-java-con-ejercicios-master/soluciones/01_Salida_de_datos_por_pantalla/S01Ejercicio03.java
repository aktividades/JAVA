/**
 * 1. Salida por pantalla.
 *
 * Solución al ejercicio 3.
 * 
 * "Aprende Java con Ejercicios" (https://leanpub.com/aprendejava)
 *
 * @author Luis José Sánchez
 */

public class S01Ejercicio03 {
  public static void main(String[] args) {
    System.out.printf("%-10s %s\n", "computer", "ordenador");
    System.out.printf("%-10s %s\n", "student", "alumno\\a");
    System.out.printf("%-10s %s\n", "cat", "gato");
    System.out.printf("%-10s %s\n", "penguin", "pingüino");
    System.out.printf("%-10s %s\n", "machine", "máquina");
    System.out.printf("%-10s %s\n", "nature", "naturaleza");
    System.out.printf("%-10s %s\n", "light", "luz");
    System.out.printf("%-10s %s\n", "green", "verde");
    System.out.printf("%-10s %s\n", "book", "libro");
    System.out.printf("%-10s %s\n", "pyramid", "pirámide");
  }
}
