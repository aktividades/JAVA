/**
 * Muestra caracteres especiales
 *
 * @author Luis J. Sánchez
 */

public class CaracteresEspeciales02 {
  public static void main(String[] args) {
    System.out.println("Una corchea: \u266A");
    System.out.print("Dos corcheas: \u266B");
  }
}
