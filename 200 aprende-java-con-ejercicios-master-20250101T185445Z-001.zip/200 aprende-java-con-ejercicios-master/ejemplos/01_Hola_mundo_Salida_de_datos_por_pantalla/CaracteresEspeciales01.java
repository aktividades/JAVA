/**
 * Muestra caracteres especiales
 *
 * @author Luis J. Sánchez
 */

public class CaracteresEspeciales01 {
  public static void main(String[] args) {
    System.out.print("Cuando programo ⌨ estoy");
    System.out.print(" muy 😆 y me siento como un ♔.");
  }
}
