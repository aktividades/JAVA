# Orden de los ejemplos

* saludo1.jsp
* saludo2.jsp
* saludo3.jsp
* saludo4.jsp
* pruebaVariable1.jsp
* pruebaVariable2.jsp
* muestraInfo.jsp
* tabla.jsp
* PasoDeCadena
* Incrementa5
* Suma
* Animales
* GatosConClase
* GatosConClaseYBocadillos
