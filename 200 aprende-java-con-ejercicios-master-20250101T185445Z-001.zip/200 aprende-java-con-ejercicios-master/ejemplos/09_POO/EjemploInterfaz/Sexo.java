/**
 * Sexo.java
 * Definición del tipo enumerado Sexo
 * @author Luis José Sánchez
 */

public enum Sexo {
  MACHO, HEMBRA, HERMAFRODITA
}
