/**
 * Libro.java
 * Definición de la clase Libro
 * @author Luis José Sánchez
 */

public class Libro {

  // atributos
  String isbn;
  String titulo;
  String autor;
  int    numeroPaginas;
}
