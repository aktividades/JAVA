/**
 * Operaciones y asignaciones
 *
 * @author Luis J. Sánchez
 */

public class Asignaciones {
  public static void main(String[] args) {

    int x = 2;
    int y = 9;

    int sum = x + y;
    System.out.println("La suma de mis variables es " + sum);
    
    int mul = x * y;
    System.out.println("La multiplicación de mis variables es " + mul);   
  }
}
