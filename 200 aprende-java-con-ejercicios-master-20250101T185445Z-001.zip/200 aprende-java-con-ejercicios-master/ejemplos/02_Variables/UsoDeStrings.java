/**
 * Uso del tipo String
 *
 * @author Luis J. Sánchez
 */

public class UsoDeStrings {
  public static void main(String[] args) {
    String miPalabra = "cerveza";
    String miFrase = "¿dónde está mi cerveza?";
  
    System.out.println("Una palabra que uso con frecuencia: " + miPalabra);
    System.out.println("Una frase que uso a veces: " + miFrase);
  }
}
