/**
 *
 * Sentencia if
 *
 * @author Luis J. Sánchez
 */

public class ComparacionCadena {
	public static void main(String[] args) { 	

		String miFruta = "naranja";
		if ("naranja".equals(miFruta))
				System.out.println("iguales");
			else
				System.out.println("distintas");
	}
}
